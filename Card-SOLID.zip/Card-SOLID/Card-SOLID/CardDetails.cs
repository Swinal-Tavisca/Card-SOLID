﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Card_SOLID
{
    abstract public class CardDetails
    {
        List<string> names = new List<string>();
        List<int> id = new List<int>();
        public void userDetails()
        {

        }
        abstract public void cardType();
    }
}
