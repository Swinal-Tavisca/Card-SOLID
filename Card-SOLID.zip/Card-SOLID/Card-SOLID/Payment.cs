﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Card_SOLID
{
    public class Payment : CardDetails
    {
        public override void cardType()
        {
            throw new NotImplementedException();
        }
        public void addPayment()
        {

        }
        public void removePayment()
        {

        }
        public void paymentMethod()
        {

        }

    }
}
