﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Card_SOLID
{
    public class ActivePurchase : CardDetails
    {
        public override void cardType()
        {
            throw new NotImplementedException();
        }
        public void addItems()
        {

        }
        public void removeItems()
        {

        }
        public void eachItemQuantity()
        {

        }
        public void totalItems()
        {

        }
    }
}
